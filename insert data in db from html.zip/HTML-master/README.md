# data-insert-in-database-from-html-page
In this we will see how to send data in database using web service(.net) from html page
