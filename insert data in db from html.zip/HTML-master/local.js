
/* Run On Page Loading */
$(function () {

    getstates();

    $(".nonum").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCodffe >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    $('.sub').click(function () {
        var sEmail = $('.email').val();
        if ($.trim(sEmail).length == 0) {
            alert('Please enter valid email address');
            e.preventDefault();
        }
        if (validateEmail(sEmail)) {
            alert('Email is valid');
        }
        else {
            alert('Invalid Email Address'); $('.email').addClass('err');
            e.preventDefault();
        }
    });

    function validateEmail(param) {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filter.test(param)) {
            return true;
        }
        else {
            return false;
        }
    }
})

$('select.quali1').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var vlsl = this.selectedIndex;
    for (var i = 1; i <= 3; i++) { $(this).closest('div.box-body').find('div.row:eq(1)>div>select>option:eq(' + (i) + ')').removeClass('hide'); }
    for (var i = 1; i <= vlsl; i++) {
        $(this).closest('div.box-body').find('div.row:eq(1)>div>select>option:eq(' + (i) + ')').addClass('hide');
        $(this).closest('div.box-body').find('div.row:eq(1)>div>select').val(0);
    }
});
$('input[type="radio"]').click(function () {
    $('#gender').val($(this).val());
});
$("#locstate").change(function () {
    var local = $("#locstate option:selected").val();
    getcities(local, 1);
    //alert($("select[name='lostate'] option:selected").index());
});
$("#perstate").change(function () {
    var permanant = $("#perstate option:selected").val();
    getcities(permanant, 2);
    //alert($("select[name='perstate'] option:selected").index());
});
/* CALCULATE Percentage */
$('input.obt,input.tot').change(function () {
    //  percentage(400, 500);
    var on = $(this).closest('div.row').find('div:eq(4)>input').val();
    var tn = $(this).closest('div.row').find('div:eq(3)>input').val();
    var per = (on / tn) * 100;
    //  alert(per);
    $(this).closest('div.row').find('div:eq(5)>input').val(per.toFixed(2));
});



/* GET STATES */
function getstates() {
    $.ajax({
        type: "POST",
        url: "RMLAUService.asmx/getstates",
        data: "{stateid:" + 0 + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            var raw = JSON.parse(r.d);
            for (var i = 0; i < raw.length; i++) {
                $('#locstate').append(
                '<option value="' + raw[i].stateid + '">' + raw[i].statename + '</option>'
                );
                $('#perstate').append(
               '<option value="' + raw[i].stateid + '">' + raw[i].statename + '</option>'
               );
            }
        },
    });
}

/* Fill Cities By State ID */
function getcities(stateid, num) {
    // alert(stateid);
    $.ajax({
        type: "POST",
        url: "RMLAUService.asmx/getcities",
        data: "{stateid:" + stateid + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            //alert(r.d[0]);
            var raw = JSON.parse(r.d);
            var name = '';
            switch (num) {
                case 1:
                    name = 'loccity';
                    break;
                case 2:
                    name = 'percity';
                    break;
            }
            $('#' + name).html('<option value="0">-select-</option>');
            for (var i = 0; i < raw.length; i++) {
                $('#' + name).append('<option value="' + raw[i].cityid + '">' + raw[i].cityname + '</option>');
            }
        },
    });
}

/* Fill Dmo data in input box*/
function fillvals() {
    $("input.st, textarea.st").each(function () {
        $(this).val($(this).closest('div').find('label').html());
    });
}


function savevals() {

    var arr = [], arr1 = [];
    $("input.st, select.st,textarea.st").each(function () {
        arr.push($(this).val())
        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).addClass('err');
        }
        else {
            $(this).removeClass('err');
            $(this).css({ 'text-transform': 'capitalize' });
        }
    });

    $(".ql").each(function () {
        arr1.push($(this).val())
        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).addClass('err');
        }
        else {

            $(this).removeClass('err');
            $(this).css({ 'text-transform': 'capitalize' });
        }
    });
    alert(arr1);

    $.ajax({
        type: "POST",
        url: "RMLAUService.asmx/insert_stu",
        data: "{param:" + JSON.stringify(arr) + ",param1:" + JSON.stringify(arr1) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            if (r.d > 0) {
                alert('save');
            }
        },
    });

    $('input[type="checkbox"]#ch1').click(function () {
        if ($(this).prop("checked") == true) {
            $('#permaddr').val($('#localaddr').val());
            $('#perstate').val($('#locstate').val());
            $('#percountry').val($('#loccountry').val());
            $('#percity').val($('#loccity').val());
            $('#perpin').val($('#locpin').val());
        }
        else if ($(this).prop("checked") == false) {
            $('#permaddr').val('');
            $('#perstate').val(0);
            $('#percountry').val('');
            $('#percity').val('');
            $('#perpin').val('');
        }
    });



    $('#btnclear').on('click', function () {
        $('#firstname').val('')
        $('#lastname').val('');
        $('#mothname').val('');
        $('#fathname').val('');
        $('#dob').val();
        $('#firstname').focus();
        return false;
    });
}
