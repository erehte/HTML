using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Serialization;
/// <summary>
/// Summary description for RMLAUService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class RMLAUService : System.Web.Services.WebService
{
    public RMLAUService()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    //public string HelloWorld()
    //{
    //    return "Hello World";
    //}
    //    public int sum()
    //{
    //        int a = 100;
    //        int b = 200;
    //        int c = a + b;
    //        return (c);
    //    }
    [WebMethod]
    public string getstates(int stateid)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myconstr"].ToString());
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "select * from dbo.states";
        DataTable dt = new DataTable();
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        con.Open();
        adp.Fill(dt);
        string mydata = dtToJSONjsSerializer(dt);
        return mydata;
    }

    [WebMethod]
    public string getcities(int stateid)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myconstr"].ToString());
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Select * from dbo.cities where stateid=" + stateid;
        DataTable dt = new DataTable();
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        con.Open();
        adp.Fill(dt);
        string mydata = dtToJSONjsSerializer(dt);
        return mydata;
    }
    
    //[WebMethod]
    //public string getcities1(int stateid)
    //{
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myconstr"].ToString());
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandType = CommandType.Text;
    //    cmd.Connection = con;
    //    cmd.CommandText = "Select * from dbo.cities where stateid=" + stateid;
    //    DataTable dt = new DataTable();
    //    SqlDataAdapter adp = new SqlDataAdapter(cmd);
    //    con.Open();
    //    adp.Fill(dt);
    //    string mydata = dtToJSONjsSerializer(dt);
    //    return mydata;
    //}
    
    //function changes in string
    public string dtToJSONjsSerializer(DataTable table)
    {
        JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
        Dictionary<string, object> childRow;
        foreach (DataRow row in table.Rows)
        {
            childRow = new Dictionary<string, object>();
            foreach (DataColumn col in table.Columns)
            {
                childRow.Add(col.ColumnName, row[col]);
            }
            parentRow.Add(childRow);
        }
        return jsSerializer.Serialize(parentRow);
    }

    [WebMethod]
    public int insert_stu(string[] param, string[] param1)
    {
        int a = 0;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myconstr"].ToString());
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "dbo.insert_student";
        cmd.Parameters.Add("@firstname", SqlDbType.VarChar).Value = param[0];
        cmd.Parameters.Add("@lastname", SqlDbType.VarChar).Value = param[1];
        cmd.Parameters.Add("@fathername", SqlDbType.VarChar).Value = param[2];
        cmd.Parameters.Add("@mothername", SqlDbType.VarChar).Value = param[3];
        cmd.Parameters.Add("@dateofbirth", SqlDbType.VarChar).Value = param[4];
        cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = param[5];
        cmd.Parameters.Add("@category", SqlDbType.VarChar).Value = param[6];
        cmd.Parameters.Add("@religion", SqlDbType.VarChar).Value = param[7];
        cmd.Parameters.Add("@Lfulladdress", SqlDbType.VarChar).Value = param[8];
        cmd.Parameters.Add("@Lcountry", SqlDbType.VarChar).Value = param[9];
        cmd.Parameters.Add("@Lstate", SqlDbType.VarChar).Value = param[10];
        cmd.Parameters.Add("@Lcity", SqlDbType.VarChar).Value = param[11];
        cmd.Parameters.Add("@Lpincode", SqlDbType.VarChar).Value = param[12];
        cmd.Parameters.Add("@Pfulladdress", SqlDbType.VarChar).Value = param[13];
        cmd.Parameters.Add("@Pcountry", SqlDbType.VarChar).Value = param[14];
        cmd.Parameters.Add("@Pstate", SqlDbType.VarChar).Value = param[15];
        cmd.Parameters.Add("@Pcity", SqlDbType.VarChar).Value = param[16];
        cmd.Parameters.Add("@Ppincode", SqlDbType.VarChar).Value = param[17];
        cmd.Parameters.Add("@mobilenumber", SqlDbType.VarChar).Value = param[19];
        cmd.Parameters.Add("@emailid", SqlDbType.VarChar).Value = param[18];
        cmd.Parameters.Add("@subcategory", SqlDbType.VarChar).Value = param[20];
        cmd.Parameters.Add("@parentsincome", SqlDbType.VarChar).Value = param[21];
        cmd.Parameters.Add("@domecile", SqlDbType.VarChar).Value = param[22];
        cmd.Parameters.Add("@mothertongue", SqlDbType.VarChar).Value = param[23];
        cmd.Parameters.Add("@weightage", SqlDbType.VarChar).Value = param[24];
        cmd.Parameters.Add("@adhar", SqlDbType.VarChar).Value = param[25];
        cmd.Parameters.Add("@bloodgroup", SqlDbType.VarChar).Value = param[26];
        cmd.Parameters.Add("@photo", SqlDbType.VarChar).Value = param[27];
        cmd.Parameters.Add("@sign", SqlDbType.VarChar).Value = param[28];
        cmd.Parameters.Add("@qualityp", SqlDbType.Structured).Value = arrtodt(param1);
        con.Open();
        a = cmd.ExecuteNonQuery();
        con.Close();
        return a;
    }

    
    public DataTable arrtodt(string[] ele)
    {
        DataTable _myDataTable = new DataTable();
        string [] ar = new string[]{"Qualification","Board","PassingYear","TotalNo","ObtainNo","Percents","Grade"};
        for (int i = 0; i < (ele.Length/2); i++)
        {
            _myDataTable.Columns.Add();
            _myDataTable.Columns[i].ColumnName = ar[i];
        }

        for (int j = 0; j < ele.Length; j++)
        {
            DataRow row = _myDataTable.NewRow();
            for (int i = 0; i < 7; i++)
            {
                row[i] = ele[i+j];
            }
            j += 6;
            _myDataTable.Rows.Add(row);
        }
        return _myDataTable;
    }

}
